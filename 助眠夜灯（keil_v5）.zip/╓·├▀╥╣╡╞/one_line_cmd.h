#ifndef __ONE_LINE_CMD_H_
#define __ONE_LINE_CMD_H_
#include <reg52.h>

//one_line
#define CLEAR           0x0A    
#define MUSIC_SELECT    0x0B    
#define VOLUME          0x0C    
#define EQ              0x0D    
#define CYCLICAL_MODE   0x0E    
#define CHANNEL         0x0F    
#define INTER_CUT       0x10    
#define PLAY            0x11    
#define PAUSE           0x12    
#define STOP            0x13    
#define PREV_MUSIC      0x14    
#define NEXT_MUSIC      0x15    
#define PREV_CATALOGUE  0x16    
#define NEXT_CATALOGUE  0x17    
#define SD_CARD         0x18    
#define USB_FLASH_DISK  0x19    
#define FLASH_DISK      0x1A    
#define SYS_HIBERNATION 0x1B    
#define CLOSE_DOWN      0x1C    

//--------------------------
void Online_trans(unsigned char dat);
void Mix_Command(unsigned char number,unsigned char command);
#endif          