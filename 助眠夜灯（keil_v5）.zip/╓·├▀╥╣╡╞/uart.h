#ifndef __UART_H_
#define __UART_H_
#include <reg52.h>

//--------------------------

void UART_Config(void);
void UART1_SendByte(unsigned char dat );

//--------------------------
void TIM2_Init(void);
//-------------delay-------------
void Delay(unsigned int nCount);
void TIM2DelayDecrement(void);
void TIM2Delay_n100us(unsigned int n100us);
//--------------------------
void IO_Init(void);

//--------------------------
void CLK_Config(void);

//-------------LED-------------
void LED_Init(void);
//-------------LED-------------
void LED_OFF(void);
//-------------LED-------------
void LED_ON(void);


#endif